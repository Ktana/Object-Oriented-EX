package Comparator;

/**
	 * Empty raw type class to implement inheritance
	 */
public class MyComparator<T> implements Comparable <T>{
	@Override
	public int compareTo(T obj)
	{
		return 0;	
	}
}
