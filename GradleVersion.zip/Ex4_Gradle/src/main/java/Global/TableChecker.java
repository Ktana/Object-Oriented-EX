package Global;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.sql.Connection;
import java.util.ArrayList;

import Database.MySQL_101;
import KML.Placemark;

public class TableChecker {

	private MySQL_101 mySQLconnector;	  
	private String origUpdateTime="";
	private String folder;
	
	public TableChecker(String ip, String user, String password, String port, String tableName, String folderPath)
	{
		this.mySQLconnector = new MySQL_101(ip, user, password, port, tableName);
		origUpdateTime = this.mySQLconnector.getUpdateDate();
		this.folder = folderPath;
	}
	  
	public void workerTableProsses(){
		String newUpdateTime = mySQLconnector.getUpdateDate();
		String errorMsg="";
		
		if(!newUpdateTime.equals("") && !origUpdateTime.equals(newUpdateTime))
		{
			errorMsg = "Table is changed!";
			origUpdateTime = newUpdateTime;
		}
			
		if(!errorMsg.equals("")){
			System.out.println(errorMsg);
			errorMsg ="";
			MainRun main = new MainRun();
			main.saveFolderPath(this.folder);
			main.saveToCSV();
			main.saveToKML();
		}
	}
}
